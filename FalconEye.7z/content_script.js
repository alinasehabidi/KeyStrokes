window.onload = () =>{
  //console.log("hey! im Auto SS function")
  chrome.runtime.sendMessage({func: 'auto_ss'});

}
