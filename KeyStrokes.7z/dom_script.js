//DoM Stuff
// alert('Dom Working');
// console.log('Dom Working');
var tableData,
    tablearr=[],
    expiryDate,
    q = new Date(), 
    d = q.getDate(),
    m = q.getMonth(),   
    y = q.getFullYear(),
    clipValue;


try {

  //selecting falgs&Audit on page load
  document.getElementById("a4").click();

  //geting table data from All td
  tableData= document.querySelectorAll("td");

  tableData.forEach(el =>  {
    //storing in an Array;
    tablearr.push(el.innerText);
  });

  //Geting index where Expiry date is assign in table Array;
  expiryDate = tablearr.indexOf("expiry") + 1;

  var dateResult = tablearr[expiryDate];
  //console.log(dateResult)

  //spliting date to creat Js Date object
  var dateParts = dateResult.split("/");

  //creating JsObj from splited date String
  var dateObj = new Date(+dateParts[2], dateParts[1]-1, +dateParts[0]); 
  //console.log(dateObj);

  // storing Current date  
  var currentDate = new Date(y,m,d);
  //console.log(currentDate)

  var placeToColor = (tablearr.indexOf("expiry") / 4) +1;
  //console.log(placeToColor);

  //Comparing Dates
  if(dateObj>currentDate){
    document.querySelector("tr:nth-child("+ placeToColor +")").style.backgroundColor = "#D5FDD5";
  }
  else{
    document.querySelector("tr:nth-child("+ placeToColor +")").style.backgroundColor = "#ff9c84";
  }
  
 // Geting Current Cust Id on Page for ease
  var currentPath = window.location.pathname.split('/');
  cId= currentPath.pop() || currentPath.pop() ;
 //
  var addId = document.querySelectorAll('h3.panel-title');
  var idAdded =addId[0];
  idAdded.innerText= 'Meta Info' + ' ( Cust ID: '  + cId + ' )' ;
 
  // var clipPromice = navigator.clipboard.readText();
  // clipValue = clipPromice.document.getElementById("outbox").innerText;
 
  // console.log(clipPromice) 
  // console.log(clipValue) 
  // var addId = document.getElementById("navbar");
  // addId.append(cId).innerText.backgroundColor = "red" ;

  //awaitc.style.backgroundColor = "#D5FDD5";
  
  // var list = document.getElementsByClassName("panel-title")[0];
  // list.getElementsByClassName("panel-title")[0].innerHTML = "Milk"
  // var  panelTitle = document.querySelector('#panel-title');

  // panelTitle.innerHTML = 'Testing here';
  //getElementsByClassName('panel-heading')[1].style.backgroundColor = "red"
  //document.getElementById("profile").style.backgroundColor = "red";
  //document.write(document.getElementsByClassName("col-md-12").innerHTML)
  
} catch (error) {
  console.log("this is the first page of dashboard") ;  
}