let ks = [ 
     
    {
        "id": "cmp",
        "name": "Camera And Mic Permission",
        "snip": "cm",
        "subj": "",
        "content" : "Seems like your browser has blocked Camera and Microphone access for the Video call Go to google chrome - settings - site settings - allow camera and Microphone - and come back to Paytm Page to proceed with Video KYC"
    },
   
    {
        "id": "linkp",
        "name": "Link to update PAN",
        "snip": "link",
        "subj": "",
        "content" : "Link to update PAN http://m.p-y.tm/pan"
    },
   
    {
        "id": "otp",
        "name": "OTP",
        "snip": "otp",
        "subj": "",
        "content" : "Your Aadhar OTP with Paytm bank has expired, so its not possible to complete your KYC at the moment, Please download the latest version of Paytm app and link your Aadhar from your profile section by generating OTP entering it to your profile, and apply again for Video KYC, Thank You."
    },

    {
        "id": "ge",
        "name":"Good Evening",
        "snip": "ge",
        "subj": "",
        "content" : "Good Evening, Please accept the videocall"
    },

    {
        "id": "ga",
        "name": "Good Afternoon",
        "snip": "ga",
        "subj": "",
        "content" : "Good Afternoon, Please accept the videocall"
    },

    {
        "id": "gm",
        "name":"Good Morning",
        "snip": "gm",
        "subj": "",
        "content": "Good Morning, Please accept the videocall"
    },


   ];
